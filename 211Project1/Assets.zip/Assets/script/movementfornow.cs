﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movementfornow : MonoBehaviour {
	public float xspeed = 0f;
	public float yspeed = 0f;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.RightArrow)) {
			xspeed = 5f;

		} else if (Input.GetKey (KeyCode.LeftArrow)) {
			xspeed = -5f;
		} else {
			xspeed = 0f;
		}
		GetComponent<Rigidbody2D> ().velocity = new Vector2 (xspeed, yspeed);
	}
}